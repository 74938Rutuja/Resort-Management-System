UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 1;


INSERT INTO users(first_name, last_name, email, password, idproof, gender, role, mobile, address, city, state, zipcode) VALUES ('sham','mehara', 'sham@test.com', 1234, NUll, NUll, NUll, NUll, NUll, NUll, NUll, NUll);

UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 1;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 2;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 3;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 4;
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 5;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 6;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 7;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 8;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 9;
UPDATE users
SET password = "$2a$10$.J1uaWgH4g9o.kViXNq0POfNAuWjDeCjRSAwNlYK0j9qaGwpEmWOa"
WHERE user_id = 10;

